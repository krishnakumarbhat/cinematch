export enum ContentType {
  Movie = 'Movie',
  Series = 'Series',
  Anime = 'Anime'
}

export interface WatchedItem {
  id: string;
  title: string;
}

export interface Recommendation {
  title: string;
  type: ContentType;
  matchScore: number;
  reason: string;
  description: string;
  year?: string;
}

export interface RecommendationResponse {
  recommendations: Recommendation[];
}
