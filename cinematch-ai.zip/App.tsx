import React, { useState } from 'react';
import { Sparkles, Loader2, PlayCircle } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import InputArea from './components/InputArea';
import WatchedList from './components/WatchedList';
import RecommendationCard from './components/RecommendationCard';
import { WatchedItem, Recommendation } from './types';
import { getRecommendations } from './services/gemini';

const App: React.FC = () => {
  const [watchedItems, setWatchedItems] = useState<WatchedItem[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAddItem = (title: string) => {
    // Prevent duplicates
    if (watchedItems.some(item => item.title.toLowerCase() === title.toLowerCase())) {
      return;
    }
    const newItem: WatchedItem = { id: uuidv4(), title };
    setWatchedItems(prev => [newItem, ...prev]);
    // Clear previous recommendations if user changes input to encourage regeneration
    if (recommendations.length > 0) {
      // Optional: keep them or clear them. Clearing makes sense to "reset" the flow.
      // setRecommendations([]); 
    }
  };

  const handleRemoveItem = (id: string) => {
    setWatchedItems(prev => prev.filter(item => item.id !== id));
  };

  const handleClearAll = () => {
    setWatchedItems([]);
    setRecommendations([]);
    setError(null);
  };

  const fetchRecommendations = async () => {
    if (watchedItems.length === 0) return;

    setLoading(true);
    setError(null);
    setRecommendations([]); // Clear old results while loading

    try {
      const titles = watchedItems.map(item => item.title);
      const data = await getRecommendations(titles);
      setRecommendations(data.recommendations);
    } catch (err) {
      setError("Failed to generate recommendations. Please try again later or check your API key.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-100 selection:bg-indigo-500/30">
      
      {/* Background Ambience */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-900/20 rounded-full blur-[120px] mix-blend-screen animate-pulse duration-[5000ms]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-[120px] mix-blend-screen animate-pulse duration-[7000ms]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex flex-col items-center">
        
        {/* Header */}
        <header className="text-center mb-12 animate-[fadeIn_1s_ease-out]">
          <div className="inline-flex items-center justify-center p-3 bg-indigo-500/10 rounded-2xl mb-6 ring-1 ring-indigo-500/20 shadow-lg shadow-indigo-500/5">
            <Sparkles className="w-8 h-8 text-indigo-400" />
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white mb-4 bg-clip-text text-transparent bg-gradient-to-r from-indigo-200 via-white to-purple-200">
            CineMatch AI
          </h1>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Discover your next obsession. Tell us what movies, series, or anime you love, 
            and our AI will curate a personalized watchlist just for you.
          </p>
        </header>

        {/* Input Section */}
        <InputArea onAdd={handleAddItem} isLoading={loading} />
        
        <WatchedList 
          items={watchedItems} 
          onRemove={handleRemoveItem} 
          onClear={handleClearAll}
        />

        {/* Action Button */}
        {watchedItems.length > 0 && (
          <div className="mb-16">
            <button
              onClick={fetchRecommendations}
              disabled={loading}
              className={`
                group relative inline-flex items-center gap-3 px-8 py-4 
                bg-gradient-to-r from-indigo-600 to-violet-600 
                hover:from-indigo-500 hover:to-violet-500 
                text-white text-lg font-bold rounded-xl 
                shadow-xl shadow-indigo-900/20 transition-all duration-300 
                hover:scale-105 active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed
                ${loading ? 'cursor-wait' : ''}
              `}
            >
              {loading ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span>Analyzing Taste Profile...</span>
                </>
              ) : (
                <>
                  <PlayCircle className="w-6 h-6 fill-white/20" />
                  <span>Generate Recommendations</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="w-full max-w-2xl p-4 bg-red-900/20 border border-red-500/30 rounded-xl text-red-200 text-center mb-12 animate-[fadeIn_0.5s]">
            {error}
          </div>
        )}

        {/* Results Grid */}
        {recommendations.length > 0 && (
          <div className="w-full animate-[fadeIn_1s_ease-out]">
            <div className="flex items-center gap-4 mb-8">
              <h2 className="text-2xl font-bold text-white">Top Picks For You</h2>
              <div className="h-px bg-slate-800 flex-grow"></div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendations.map((rec, index) => (
                <RecommendationCard 
                  key={`${rec.title}-${index}`} 
                  data={rec} 
                  delay={index * 100} // Staggered animation
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default App;