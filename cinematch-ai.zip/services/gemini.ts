import { GoogleGenAI, Type } from "@google/genai";
import { RecommendationResponse, ContentType } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getRecommendations = async (watchedTitles: string[]): Promise<RecommendationResponse> => {
  if (watchedTitles.length === 0) {
    return { recommendations: [] };
  }

  const prompt = `
    The user has watched and enjoyed the following movies, series, and anime:
    ${watchedTitles.map(t => `- ${t}`).join('\n')}

    Please recommend 6-9 new items they might like. 
    Mix the types (Movie, Series, Anime) if appropriate based on their taste.
    Provide a match score (0-100) based on similarity.
    Provide a compelling reason why it fits their taste.
    Provide a short, punchy description.
    Infer the release year if known.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "You are an expert film, TV, and anime critic with a deep understanding of genre, tone, and direction.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  type: { 
                    type: Type.STRING, 
                    enum: [ContentType.Movie, ContentType.Series, ContentType.Anime] 
                  },
                  matchScore: { type: Type.NUMBER },
                  reason: { type: Type.STRING },
                  description: { type: Type.STRING },
                  year: { type: Type.STRING }
                },
                required: ["title", "type", "matchScore", "reason", "description"]
              }
            }
          }
        }
      }
    });

    const jsonText = response.text;
    if (!jsonText) {
      throw new Error("No data returned from Gemini");
    }

    return JSON.parse(jsonText) as RecommendationResponse;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};